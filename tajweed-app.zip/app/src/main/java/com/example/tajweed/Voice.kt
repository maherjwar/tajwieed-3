package com.example.tajweed

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import java.io.File

/**
 * تسجيل صوت المتعلم ليقارنه بالتلاوة الأصلية. بلا أي تقييم آلي.
 * التسجيل ملف مؤقت في ذاكرة التطبيق المؤقتة ويُحذف عند الانتقال للسؤال التالي، ولا يُرفع إلى أي مكان.
 */
class Recorder(private val ctx: Context) {
    private val file = File(ctx.cacheDir, "mine.m4a")
    private var rec: MediaRecorder? = null
    private var mp: MediaPlayer? = null
    var recording by mutableStateOf(false); private set
    var playing by mutableStateOf(false); private set
    var has by mutableStateOf(false); private set
    var error by mutableStateOf(""); private set

    fun start(): Boolean {
        stopPlay(); release(); error = ""
        return try {
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(96000)
            r.setMaxDuration(30_000)
            r.setOutputFile(file.absolutePath)
            r.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) stop()
            }
            r.prepare()
            r.start()
            rec = r; recording = true; has = false
            true
        } catch (e: Exception) {
            release(); error = "تعذّر بدء التسجيل"; false
        }
    }

    fun stop() {
        val r = rec ?: return
        rec = null; recording = false
        has = try { r.stop(); file.exists() && file.length() > 1000 } catch (e: Exception) { false }
        try { r.release() } catch (e: Exception) { }
        if (!has) error = "التسجيل قصير جدًا، حاول مرة أخرى"
    }

    fun play(onDone: () -> Unit = {}) {
        if (!has) { onDone(); return }
        stopPlay()
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).setUsage(AudioAttributes.USAGE_MEDIA).build())
            p.setDataSource(file.absolutePath)
            p.setOnPreparedListener { it.start() }
            p.setOnCompletionListener { m -> playing = false; if (mp === m) mp = null; m.release(); onDone() }
            p.setOnErrorListener { m, _, _ -> playing = false; if (mp === m) mp = null; m.release(); true }
            mp = p; playing = true
            p.prepareAsync()
        } catch (e: Exception) { playing = false }
    }

    fun stopPlay() {
        try { mp?.release() } catch (e: Exception) { }
        mp = null; playing = false
    }

    private fun release() {
        rec?.let { try { it.release() } catch (e: Exception) { } }
        rec = null; recording = false
    }

    // يوقف كل شيء ويحذف التسجيل المؤقت
    fun reset() {
        stop(); stopPlay(); has = false; error = ""
        try { file.delete() } catch (e: Exception) { }
    }
}

// شريط التسجيل أسفل المثال: سجّل ← قارن (الأصلي ثم صوتك) ← استمع لتسجيلك
@Composable
fun VoiceRow(rc: Recorder, pl: Player, st: Store, ref: String, clip: Pair<Int, Int>?) {
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { pl.stop(); rc.start() }
    }
    fun record() {
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pl.stop(); rc.start()
        } else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    Column(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        T("🎙 رتّل المثال بصوتك ثم قارن بالتلاوة الأصلية", 14, FontWeight.Medium, Muted, TextAlign.Center, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (rc.recording) {
                Box(Modifier.clip(CircleShape).background(Red).clickable { rc.stop() }.padding(horizontal = 18.dp, vertical = 8.dp)) {
                    T("⏹ إنهاء التسجيل", 16, FontWeight.Medium, Color.White)
                }
            } else {
                Box(Modifier.clip(CircleShape).background(Soft).clickable { rc.stopPlay(); record() }.padding(horizontal = 18.dp, vertical = 8.dp)) {
                    T(if (rc.has) "🎙 أعد التسجيل" else "🎙 سجّل صوتك", 16, FontWeight.Medium, GreenT)
                }
            }
        }
        if (rc.has && !rc.recording) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.clip(CircleShape).background(if (rc.playing) Gold else GoldSoft)
                    .clickable {
                        if (rc.playing || pl.busy) { rc.stopPlay(); pl.stop() }
                        else {
                            pl.speed = st.speed; pl.lead = st.lead; pl.tail = st.tail
                            // التلاوة الأصلية أولًا، وعند انتهائها يُشغَّل تسجيلك
                            pl.play(ref, clip) { rc.play() }
                        }
                    }.padding(horizontal = 18.dp, vertical = 8.dp)) {
                    T(if (rc.playing || pl.busy) "⏹ إيقاف" else "🔁 قارن: الأصلي ثم صوتك", 16, FontWeight.Medium, GoldDark)
                }
                if (!rc.playing) Box(Modifier.clip(CircleShape).background(Soft).clickable { pl.stop(); rc.play() }
                    .padding(horizontal = 18.dp, vertical = 8.dp)) {
                    T("▶ صوتك فقط", 16, FontWeight.Medium, GreenT)
                }
            }
        }
        if (rc.error.isNotEmpty()) T(rc.error, 14, c = Red, a = TextAlign.Center, m = Modifier.fillMaxWidth())
        if (rc.recording) T("جارٍ التسجيل... اقرأ المثال ثم اضغط إنهاء", 14, FontWeight.Medium, Red, TextAlign.Center, Modifier.fillMaxWidth())
        else T("للمقارنة بأذنك أنت، بلا تقييم آلي. يبقى التسجيل على جهازك مؤقتًا ولا يُرفع.", 13, c = Muted, a = TextAlign.Center, m = Modifier.fillMaxWidth())
    }
}
