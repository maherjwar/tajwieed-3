package com.example.tajweed

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import java.security.SecureRandom

/**
 * تحدي الأصدقاء: مجموعة برمز من ٦ خانات، ولوحة ترتيب أسبوعية بحسب النقاط.
 * البيانات: groups/{code} (الاسم والمنشئ) و groups/{code}/scores/{uid} (الاسم الأول ونقاط الأسبوع).
 * الدخول لا يتم إلا بمعرفة الرمز، ولا يقرأ اللوحة إلا عضو في المجموعة (انظر قواعد Firestore في FIREBASE_SETUP.md).
 */
object Friends {
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    class Member(val uid: String, val name: String, val points: Int)
    class Board(val title: String, val code: String, val members: List<Member>)

    private fun user(): FirebaseUser? = try { FirebaseAuth.getInstance().currentUser } catch (e: Exception) { null }

    // نشارك الاسم الأول فقط مع أعضاء المجموعة
    private fun shownName(u: FirebaseUser): String {
        val first = u.displayName?.trim()?.split(" ")?.firstOrNull().orEmpty()
        return first.ifEmpty { "متعلّم" }.take(20)
    }

    private fun score(u: FirebaseUser, st: Store): Map<String, Any> = mapOf(
        "name" to shownName(u),
        "xp" to st.weekPoints().toLong(),
        "week" to st.weekId(),
        "updated" to System.currentTimeMillis()
    )

    private fun newCode(): String {
        val r = SecureRandom()
        return String(CharArray(6) { ALPHABET[r.nextInt(ALPHABET.length)] })
    }

    suspend fun create(st: Store, name: String): String {
        val u = user() ?: return "سجّل الدخول بحساب Google أولًا"
        val title = name.trim().take(30)
        if (title.isEmpty()) return "اكتب اسمًا للمجموعة"
        return try {
            val db = FirebaseFirestore.getInstance()
            var made: String? = null
            for (k in 0 until 5) {
                val code = newCode()
                val ref = db.collection("groups").document(code)
                if (!ref.get().await().exists()) {
                    ref.set(mapOf("name" to title, "owner" to u.uid, "created" to System.currentTimeMillis())).await()
                    ref.collection("scores").document(u.uid).set(score(u, st)).await()
                    st.setGroup(u.uid, code)
                    made = code
                    break
                }
            }
            if (made == null) "تعذّر إنشاء رمز فريد، حاول مرة أخرى" else "تم إنشاء المجموعة. شارك رمزها مع أصدقائك: $made"
        } catch (e: Exception) {
            "تعذّر الإنشاء: ${e.javaClass.simpleName} ${e.message?.take(80) ?: ""}"
        }
    }

    suspend fun join(st: Store, rawCode: String): String {
        val u = user() ?: return "سجّل الدخول بحساب Google أولًا"
        val code = rawCode.trim().uppercase()
        if (code.length != 6) return "الرمز مكوّن من ٦ خانات"
        return try {
            val db = FirebaseFirestore.getInstance()
            val ref = db.collection("groups").document(code)
            if (!ref.get().await().exists()) return "لا توجد مجموعة بهذا الرمز"
            ref.collection("scores").document(u.uid).set(score(u, st)).await()
            st.setGroup(u.uid, code)
            "تم الانضمام إلى المجموعة"
        } catch (e: Exception) {
            "تعذّر الانضمام: ${e.javaClass.simpleName} ${e.message?.take(80) ?: ""}"
        }
    }

    suspend fun leave(st: Store): String {
        val u = user() ?: return "لم تسجّل الدخول"
        val code = st.groupOf(u.uid) ?: return ""
        try {
            FirebaseFirestore.getInstance().collection("groups").document(code)
                .collection("scores").document(u.uid).delete().await()
        } catch (e: Exception) { }
        st.setGroup(u.uid, null)
        return "غادرت المجموعة"
    }

    suspend fun load(st: Store): Pair<Board?, String> {
        val u = user() ?: return null to "سجّل الدخول بحساب Google أولًا"
        val code = st.groupOf(u.uid) ?: return null to ""
        return try {
            val db = FirebaseFirestore.getInstance()
            val ref = db.collection("groups").document(code)
            val g = ref.get().await()
            if (!g.exists()) {
                st.setGroup(u.uid, null)
                return null to "هذه المجموعة لم تعد موجودة"
            }
            // نحدّث نقاطنا أولًا لتظهر آخر نتيجة في اللوحة
            try { ref.collection("scores").document(u.uid).set(score(u, st)).await() } catch (e: Exception) { }
            val snap = ref.collection("scores").limit(100).get().await()
            val week = st.weekId()
            val list = snap.documents.mapNotNull { d ->
                val n = d.getString("name") ?: return@mapNotNull null
                val pts = if ((d.getLong("week") ?: -1L) == week) (d.getLong("xp") ?: 0L).toInt() else 0
                Member(d.id, n, pts)
            }.sortedWith(compareByDescending<Member> { it.points }.thenBy { it.name })
            Board(g.getString("name") ?: "مجموعتي", code, list) to ""
        } catch (e: Exception) {
            null to "تعذّر تحميل اللوحة، تحقق من الاتصال: ${e.javaClass.simpleName}"
        }
    }

    // يرفع نقاط الأسبوع إن كان المستخدم عضوًا (يُستدعى مع حفظ التقدم)
    fun push(st: Store) {
        try {
            val u = user() ?: return
            val code = st.groupOf(u.uid) ?: return
            FirebaseFirestore.getInstance().collection("groups").document(code)
                .collection("scores").document(u.uid).set(score(u, st))
        } catch (e: Exception) { }
    }
}

@Composable
fun Field(value: String, hint: String, onChange: (String) -> Unit) {
    val style = TextStyle(fontFamily = Qomra, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Ink)
    BasicTextField(value, onChange, Modifier.fillMaxWidth(), textStyle = style, singleLine = true,
        cursorBrush = SolidColor(Green),
        decorationBox = { inner ->
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surface)
                .border(2.dp, Grey, RoundedCornerShape(14.dp)).padding(14.dp)) {
                if (value.isEmpty()) T(hint, 18, c = Muted)
                inner()
            }
        })
}

@Composable
fun FriendsScreen(st: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var board by remember { mutableStateOf<Friends.Board?>(null) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var mode by remember { mutableIntStateOf(0) } // 0 قائمة، 1 إنشاء، 2 انضمام
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    val me = try { FirebaseAuth.getInstance().currentUser?.uid } catch (e: Exception) { null }

    fun reload() {
        scope.launch {
            busy = true
            val (b, m) = Friends.load(st)
            board = b; if (m.isNotEmpty()) msg = m
            busy = false
        }
    }
    LaunchedEffect(st.group, st.account) {
        if (st.account != null && st.group != null) { reload() } else { board = null }
    }

    Column(Modifier.fillMaxSize().background(Cream)) {
        TopBar("تحدي الأصدقاء", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (st.account == null) {
                Column(Modifier.card(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    T("👥 تنافس مع أصدقائك", 20, FontWeight.Bold, GreenT)
                    T("أنشئ مجموعة وأرسل رمزها لأصدقائك، وتابعوا ترتيب النقاط الأسبوعي. نحتاج حساب Google لنعرف من أنت.", 15, c = Muted)
                    Btn("تسجيل الدخول بحساب Google") {
                        scope.launch { msg = "جارٍ تسجيل الدخول..."; msg = Cloud.signIn(ctx, st) }
                    }
                }
            } else if (st.group == null) {
                Column(Modifier.card(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    T("👥 تنافس مع أصدقائك", 20, FontWeight.Bold, GreenT)
                    T("ترتيب أسبوعي بحسب النقاط، يبدأ من جديد كل يوم أحد. يرى أعضاء المجموعة اسمك الأول ونقاطك فقط.", 15, c = Muted)
                }
                if (mode == 0) {
                    Btn("إنشاء مجموعة جديدة") { mode = 1; msg = "" }
                    Btn("الانضمام برمز", Gold, Color(0xFFA67F1E)) { mode = 2; msg = "" }
                } else if (mode == 1) {
                    Column(Modifier.card(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        T("اسم المجموعة", 17, FontWeight.Bold)
                        Field(name, "مثال: أسرة النور") { name = it.take(30) }
                        Btn("إنشاء", on = !busy && name.isNotBlank()) {
                            scope.launch { busy = true; msg = Friends.create(st, name); busy = false }
                        }
                        Btn("رجوع", Color(0xFF6B7F76), Color(0xFF4E5F57)) { mode = 0 }
                    }
                } else {
                    Column(Modifier.card(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        T("رمز المجموعة", 17, FontWeight.Bold)
                        Field(code, "٦ خانات، مثال: K7M2QX") { code = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(6) }
                        Btn("انضمام", on = !busy && code.length == 6) {
                            scope.launch { busy = true; msg = Friends.join(st, code); busy = false }
                        }
                        Btn("رجوع", Color(0xFF6B7F76), Color(0xFF4E5F57)) { mode = 0 }
                    }
                }
            } else {
                val b = board
                if (b == null) {
                    T(if (busy) "جارٍ تحميل اللوحة..." else "لم تُحمَّل اللوحة بعد", 16, c = Muted)
                    if (!busy) Btn("إعادة المحاولة") { reload() }
                } else {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(GreenDark, Green))).padding(16.dp)) {
                        T(b.title, 22, FontWeight.Bold, Color.White)
                        T("تنتهي هذه الجولة بعد ${st.weekDaysLeft()} ${if (st.weekDaysLeft() == 1) "يوم" else "أيام"}", 14, FontWeight.Medium, Color(0xFFFAF5E9))
                    }
                    b.members.forEachIndexed { i, m ->
                        val mine = m.uid == me
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(if (mine) GoldSoft else Surface)
                            .border(2.dp, if (mine) Gold else Grey, RoundedCornerShape(16.dp)).padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            T(when (i) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${i + 1}" }, 22, FontWeight.Bold, GoldDark,
                                TextAlign.Center, Modifier.width(40.dp))
                            T(if (mine) "${m.name} (أنت)" else m.name, 18, FontWeight.Bold, Ink, m = Modifier.weight(1f))
                            T("⭐ ${m.points}", 18, FontWeight.Bold, GreenT)
                        }
                    }
                    Column(Modifier.card(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        T("رمز المجموعة", 15, FontWeight.Medium, Muted)
                        T(b.code, 30, FontWeight.Bold, GreenT, TextAlign.Center, Modifier.fillMaxWidth())
                        Btn("أرسل الرمز لأصدقائك", Gold, Color(0xFFA67F1E)) {
                            try {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "انضم إلى مجموعة «${b.title}» في تطبيق تجويد، رمز المجموعة: ${b.code}")
                                }
                                ctx.startActivity(Intent.createChooser(send, "أرسل الرمز").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Exception) { }
                        }
                        Btn("تحديث اللوحة", on = !busy) { reload() }
                        Btn("مغادرة المجموعة", Red, Color(0xFFA9322A)) {
                            scope.launch { busy = true; msg = Friends.leave(st); board = null; busy = false }
                        }
                    }
                }
            }
            if (msg.isNotEmpty()) Box(Modifier.card()) { T(msg, 15, FontWeight.Medium, GreenT) }
        }
    }
}
