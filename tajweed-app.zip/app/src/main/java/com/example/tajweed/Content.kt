package com.example.tajweed

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONArray
import org.json.JSONObject

// ---------- الأمثلة المضمّنة في التطبيق (MoreExamples.kt) ----------
fun withExtras(base: List<Lesson>): List<Lesson> = base.map { l ->
    val more = moreExamples.filter { e -> e.lesson == l.title && e.a in l.opts.indices && l.items.none { it.first == e.v } }
    if (more.isEmpty()) l else l.copy(items = l.items + more.map { Triple(it.v, it.a, it.w) })
}

// تسجيل الحروف الملوّنة والمقاطع الصوتية للأمثلة المضمّنة (لا يستبدل ما هو موجود)
fun installExtras(): Boolean {
    moreExamples.forEach { e ->
        val k = "${e.lesson}|${e.v}"
        if (e.marks.isNotEmpty() && !markMap.containsKey(k)) markMap[k] = e.marks
        if (e.ref.isNotEmpty() && !audioRefs.containsKey(e.v)) {
            audioRefs[e.v] = e.ref
            audioClips[e.v] = e.from to e.to
        }
    }
    return true
}

/**
 * تحديث الدروس عن بُعد دون إعادة تثبيت التطبيق.
 * المصدر: مجموعة lessons في Firestore (قراءة عامة، والكتابة من لوحة Firebase فقط).
 * تُحفظ آخر نسخة نزلت في الجهاز وتُدمج عند فتح التطبيق، فيعمل التطبيق كاملًا دون إنترنت.
 */
object Content {
    private const val PREFS = "content"
    private const val GAP = 6 * 3600_000L

    class Result(val changed: Boolean, val msg: String)

    // يُستدعى عند فتح التطبيق قبل إنشاء Store
    fun loadCached(ctx: Context) {
        try {
            val raw = ctx.getSharedPreferences(PREFS, 0).getString("json", null) ?: return
            merge(JSONArray(raw))
        } catch (e: Exception) { }
    }

    suspend fun refresh(ctx: Context, force: Boolean): Result {
        if (!Cloud.ready(ctx)) return Result(false, "الربط غير مفعّل: ملف google-services.json غير مضاف للمشروع")
        val sp = ctx.getSharedPreferences(PREFS, 0)
        val now = System.currentTimeMillis()
        if (!force && now - sp.getLong("checked", 0L) < GAP) return Result(false, "")
        return try {
            val db = FirebaseFirestore.getInstance()
            val ver = db.collection("meta").document("lessons").get().await().getLong("version") ?: -1L
            if (!force && ver >= 0 && ver == sp.getLong("version", -2L)) {
                sp.edit().putLong("checked", now).apply()
                Result(false, "")
            } else {
                val snap = db.collection("lessons").get().await()
                val arr = JSONArray()
                snap.documents.sortedBy { it.id }.forEach { d ->
                    val data = d.data
                    if (data != null) arr.put(toJson(data))
                }
                val text = arr.toString()
                val changed = text != sp.getString("json", null)
                sp.edit().putString("json", text).putLong("version", ver).putLong("checked", now).apply()
                if (changed) Result(true, "تم تنزيل دروس وأمثلة جديدة")
                else Result(false, "دروسك محدّثة")
            }
        } catch (e: Exception) {
            Result(false, "تعذّر التحديث: ${e.javaClass.simpleName} ${e.message?.take(80) ?: ""}")
        }
    }

    private fun toJson(v: Any?): Any? = when (v) {
        is Map<*, *> -> JSONObject().also { o ->
            v.forEach { (k, x) -> if (k is String) o.put(k, toJson(x) ?: JSONObject.NULL) }
        }
        is List<*> -> JSONArray().also { a -> v.forEach { a.put(toJson(it) ?: JSONObject.NULL) } }
        is Number, is String, is Boolean -> v
        else -> null
    }

    // يبني قائمة الدروس: الأساسية + الأمثلة المضمّنة + ما نزل من Firestore.
    // أمثلة تحمل عنوان درس موجود تُضاف إليه، وعنوان جديد يُنشئ درسًا جديدًا في آخر القائمة (لا يغيّر ترتيب الدروس الحالية فيبقى تقدم المتعلم سليمًا).
    private fun merge(remote: JSONArray) {
        var list = withExtras(baseLessons)
        val fresh = ArrayList<Pair<Int, Lesson>>()
        for (n in 0 until remote.length()) {
            val o = remote.optJSONObject(n) ?: continue
            if (o.optBoolean("disabled", false)) continue
            val title = o.optString("title").trim()
            if (title.isEmpty()) continue
            val idx = list.indexOfFirst { it.title == title }
            if (idx >= 0) {
                val l = list[idx]
                val items = parseItems(l, o.optJSONArray("items"))
                if (items.isNotEmpty()) list = list.toMutableList().also { it[idx] = l.copy(items = l.items + items) }
            } else {
                val oa = o.optJSONArray("opts") ?: continue
                val opts = (0 until oa.length()).map { oa.optString(it).trim() }.filter { it.isNotEmpty() }
                if (opts.size !in 2..5) continue
                val shell = Lesson(title, o.optString("unit").trim().ifEmpty { null }, o.optString("intro"),
                    o.optString("ask").ifEmpty { "ما الحكم؟" }, opts, emptyList(), null, o.optString("noun").ifEmpty { "حكم" })
                val items = parseItems(shell, o.optJSONArray("items"))
                if (items.size >= 3) fresh.add(o.optInt("order", 0) to shell.copy(items = items))
            }
        }
        lessons = list + fresh.sortedBy { it.first }.map { it.second }
        unitStarts = lessons.indices.filter { lessons[it].unit != null }
    }

    private fun parseItems(l: Lesson, arr: JSONArray?): List<Triple<String, Int, String>> {
        if (arr == null) return emptyList()
        val out = ArrayList<Triple<String, Int, String>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val v = o.optString("v").trim()
            val w = o.optString("w").trim()
            val a = o.optInt("a", -1)
            if (v.isEmpty() || v.length > 80 || w.isEmpty() || w.length > 700 || a !in l.opts.indices) continue
            if (l.items.any { it.first == v } || out.any { it.first == v }) continue
            out.add(Triple(v, a, w))
            val ma = o.optJSONArray("marks")
            if (ma != null) {
                val marks = (0 until ma.length()).map { ma.optString(it) }.filter { it.isNotEmpty() && v.contains(it) }
                if (marks.isNotEmpty() && !markMap.containsKey("${l.title}|$v")) markMap["${l.title}|$v"] = marks
            }
            val ref = o.optString("ref")
            val begin = o.optInt("from", -1)
            val end = o.optInt("to", -1)
            if (ref.length == 6 && ref.all { it.isDigit() } && !audioRefs.containsKey(v)) {
                audioRefs[v] = ref
                if (begin >= 0 && end > begin && end <= 600_000) audioClips[v] = Pair(begin, end)
            }
        }
        return out
    }
}
