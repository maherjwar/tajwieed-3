# إعداد Firebase (مرة واحدة)

## بصمة التوقيع (SHA-1) للمفتاح الثابت المرفق في المشروع
B7:6F:59:29:02:9C:10:A2:8C:C5:5E:80:08:F8:9D:1D:F5:69:F7:16

## قواعد Firestore (الصقها كاملة في Firestore ← Rules ← Publish)
الميزات الجديدة (الدروس عن بُعد وتحدي الأصدقاء) لا تعمل إلا بعد نشر هذه القواعد.

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // تقدم المتعلم: خاص بصاحبه
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }

    // الدروس عن بُعد: قراءة عامة، والكتابة من لوحة Firebase فقط
    match /meta/{doc}    { allow read: if true; allow write: if false; }
    match /lessons/{doc} { allow read: if true; allow write: if false; }

    // تحدي الأصدقاء
    match /groups/{code} {
      allow get: if request.auth != null;      // يعرف الرمز فقط من يصل للمجموعة
      allow list: if false;                    // لا يمكن تصفح المجموعات
      allow create: if request.auth != null
        && request.resource.data.owner == request.auth.uid
        && request.resource.data.name is string
        && request.resource.data.name.size() <= 30;
      allow update, delete: if false;

      match /scores/{uid} {
        // لا يقرأ اللوحة إلا عضو (له سجل نقاط في المجموعة)
        allow read: if request.auth != null
          && exists(/databases/$(database)/documents/groups/$(code)/scores/$(request.auth.uid));
        allow create, update: if request.auth != null && request.auth.uid == uid
          && exists(/databases/$(database)/documents/groups/$(code))
          && request.resource.data.xp is int
          && request.resource.data.xp >= 0 && request.resource.data.xp < 100000
          && request.resource.data.name is string
          && request.resource.data.name.size() <= 20;
        allow delete: if request.auth != null && request.auth.uid == uid;
      }
    }
  }
}
```

## تحدي الأصدقاء
- يُنشئ المتعلم مجموعة فيحصل على رمز من ٦ خانات ويرسله لأصدقائه، وينضمون به.
- الترتيب أسبوعي بحسب النقاط، ويبدأ الأسبوع يوم الأحد (بالتوقيت العالمي UTC، أي الساعة ٣ فجرًا بتوقيت السعودية).
- يرى أعضاء المجموعة الاسم الأول من حساب Google والنقاط فقط.
- النقاط يرسلها التطبيق نفسه فلا تُضمن ضد التلاعب، والغرض منها التنافس بين الأصدقاء.
- مجموعة واحدة لكل حساب. حدّ اللوحة ١٠٠ عضو.

## تحديث الدروس عن بُعد
يقرأ التطبيق عند فتحه (مرة كل ٦ ساعات على الأكثر) المستند `meta/lessons` ثم المجموعة `lessons`، ويحفظ آخر نسخة في الجهاز فيعمل دون إنترنت.

**بعد أي تعديل ارفع الحقل `version` (رقم) في المستند `meta/lessons`**، وإلا فلن يتنزّل التحديث (يوفّر هذا قراءات Firestore). زر «تحديث الدروس الآن» في الإعدادات يتجاوز الرقم ويجلب كل شيء.

كل مستند في `lessons` أحد نوعين:

**١) أمثلة جديدة لدرس موجود** — اجعل `title` مطابقًا تمامًا لعنوان الدرس (مثل `النون الساكنة`):
```
title: "النون الساكنة"
items: [
  { v: "مِنْ شَرِّ", a: 3, w: "التعليل الذي يظهر بعد الإجابة", marks: ["نْ", "شَ"],
    ref: "113002", from: 0, to: 2122 }
]
```
- `a`: رقم الحكم الصحيح في خيارات الدرس ويبدأ من ٠.
- `marks` (اختياري): الحروف الملوّنة، ويجب أن تكون جزءًا من نص `v`.
- `ref` و`from` و`to` (اختيارية): رقم السورة والآية SSSAAA ومقطع التلاوة بالمللي ثانية.

**٢) درس جديد** — عنوان غير موجود، ويُضاف في آخر القائمة:
```
title: "الوقف والابتداء"   unit: "الوحدة ٧: ..." (اختياري، يبدأ وحدة جديدة)
intro: "شرح الدرس"          ask: "ما حكم ...؟"
opts: ["خيار أ", "خيار ب"]  (من ٢ إلى ٥)    noun: "حكم" (اختياري)
order: 1                    (ترتيب الدروس الجديدة)
items: [ ... ٣ أمثلة على الأقل ... ]
```
لا تحذف درسًا نُشر ولا تغيّر ترتيبه، لأن نجوم المتعلمين محفوظة بحسب الموضع. لإخفاء مستند مؤقتًا ضع `disabled: true`.

أي مثال أو درس غير صالح (خيار خارج المدى، نص فارغ…) يُتجاهل دون أن يتأثر التطبيق.

## تسجيل الصوت
يطلب التطبيق إذن الميكروفون عند أول تسجيل. التسجيل ملف مؤقت على الجهاز ولا يُرفع إلى أي مكان.
